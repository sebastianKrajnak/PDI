#!/bin/sh

exec ./run.sh sample-scripts/cetnost-jmena-dnar-2016.pig ../cetnost-jmena-dnar-2016/cetnost-jmena-dnar.csv /tmp/cetnost-jmena-dnar-2016.pig_output
