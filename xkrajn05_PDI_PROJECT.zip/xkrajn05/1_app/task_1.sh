#!/bin/sh

exec ./run.sh ../cetnost-jmena-dnar-2016/jmena.txt /tmp/jmena-wordcount.mr_output
