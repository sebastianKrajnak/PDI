#!/bin/sh

exec ./run.sh ../cetnost-jmena-dnar-2016/jmena.txt /tmp/jmena-currencystats.spark_output
